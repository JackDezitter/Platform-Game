typeSearchIndex = [{"l": "All Classes", "url": "allclasses-index.html"}, {"p": "game", "l": "Ammo"}, {
    "p": "game",
    "l": "Attack"
}, {"p": "game", "l": "Avatar"}, {"p": "game", "l": "BonusLife"}, {"p": "game", "l": "Damage"}, {
    "p": "game",
    "l": "Doorway"
}, {"p": "game", "l": "Enemy"}, {"p": "game", "l": "FlipCharacter"}, {"p": "game", "l": "Game"}, {
    "p": "game",
    "l": "GameLevel"
}, {"p": "game", "l": "GameLoader"}, {"p": "game", "l": "GameSaver"}, {"p": "game", "l": "Level1"}, {
    "p": "game",
    "l": "Level2"
}, {"p": "game", "l": "Level3"}, {"p": "game", "l": "Level4"}, {"p": "game", "l": "Menu"}, {
    "p": "game",
    "l": "MenuButton"
}, {"p": "game", "l": "MovementController"}, {"p": "game", "l": "MyView"}, {
    "p": "game",
    "l": "Projectile"
}, {"p": "game", "l": "Shoot"}];